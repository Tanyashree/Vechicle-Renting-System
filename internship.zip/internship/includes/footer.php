
<footer style=" background-color: #36454f;margin-top:100px;">
		<div id="about" class="wrapper footer">
			<ul>
				<li class="links">
					<ul>
						<li>OUR COMPANY</li>
						<li><a href="#">About Us</a></li>
						<li><a href="#">Terms</a></li>
						<li><a href="#">Policy</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</li>

				<li class="links">
					<ul>
						<li>OTHERS</li>
						<li><a href="#">...</a></li>
						<li><a href="#">...</a></li>
						<li><a href="#">...</a></li>
						<li><a href="#">...</a></li>
					</ul>
				</li>

				<li class="links">
					<ul>
						<li>OUR Vehicle TYPES</li>
						<li><a href="#">Mercedes</a></li>
						<li><a href="#">Range Rover</a></li>
						<li><a href="#">Dukati</a></li>
						<li><a href="#">Others.</a></li>
					</ul>
				</li>
	<li class="about">
<h2 style="color:#ffffff">Our vehicles in Vellore</h2>
					<p>Family vacation? On business? Choosing KIRI vehicle for your rental in Goa will make any visit stress-free. With a range of car ,van,bicycles,bike rentals to choose from, KIRI Vellore caters to all needs. From city and family options like Peugeot 208, VW Polo, Renault Megane; or luxury vehicles such as Audi A4 or Jeep Renegade. If you�re looking for something a little bigger, our van rental includes reliable models including Renault Master and Iveco Daily.
</p>
					<ul>
						<li><a href="#" class="facebook" target="_blank"></a></li>
						<li><a href="#" class="twitter" target="_blank"></a></li>
						<li><a href="#" class="google" target="_blank"></a></li>
						<li><a href="#" class="skype"></a></li>
					</ul>
				</li>
			</ul>
		</div>

		<div class="copyrights wrapper">
			Copyright &copy; <?php echo date("Y")?> All Rights Reserved | Designed by <a style="color:white" href= "#">TANYA</a>
		</div>
	</footer><!--  end footer  -->
	
</body>
</html>