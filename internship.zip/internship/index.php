
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Vehicle Rental</title>
	<meta charset="utf-8">
	<meta name="author" content="pixelhint.com">
	<meta name="description" content="La casa free real state fully responsive html5/css3 home page website template"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" type="text/css" href="css/index.css">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
</head>
<body style="background-color:#bfd9f2">
	<section class="hello">
		<?php
			include 'header.php';
		?>	
<div class="slideshow-container" style="margin-top:35px;">

<div class="mySlides fade">
  <div class="numbertext">1 / 4</div>
  <img class="slideimg" src="img\bike.jpg" style="width:100%">
  <div class="text"><p>You Don't Know How Good you Are</p><p> Until You Actually</p><p> Get Out On A Bike And Get Riding</p></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 4</div>
  <img class="slideimg" src="img\bicycle.jpg" style="width:100%">
  <div class="text"><p>Cycling A Day </p><p>Keeps The Doctor Away</p></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 4</div>
  <img class="slideimg" src="img\car1.jpg" style="width:100%">
  <div class="text"><p>Take A Car</p><p> And Drive To,</p> <p>Your Dream Location</p></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">4 / 4</div>
  <img class="slideimg" src="img\traveller_van.jpg" style="width:100%">
  <div class="text"><p>For A Family Ride</p><p> Book A Traveller</p></div>
</div>
<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>
<div style="text-align:center;margin-bottom:-133px;">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
  <span class="dot" onclick="currentSlide(4)"></span>
</div>
<script src="js/index.js"></script>
	
				<?php include_once "includes/footer.php"; ?>
