<?php
	session_start();
	error_reporting("E-NOTICE");
?>
<head>
  <link rel="stylesheet" href="css/index.css">
</head>
<header>
							<?php
						if(!$_SESSION['email'] && (!$_SESSION['pass'])){
					?>
					<div class="topnav-information">
  <img class="logo" src="img\logo\logo.png" width=90px height=90px style="margin-top: 0px;">
 <a href="https://goo.gl/maps/CYubAdisUANTEca68"> <p class="commons"><img src="img\logo\location1.png" width=50px height=50px>Sanjay Palace Agra.</p></a>
 <a href="https://gmail.com" target="_blank"> <p class="commons"><img src="img\logo\mail.png" width=50px height=50px>contactus123@gmail.com</p></a>
  <p class="commons"><img src="img\logo\call.png" width=50px height=50px>+9808809754/9675596901</p>
  <p class ="follow_us" style="margin-left: 30px;margin-top: 30px">Follow Us On :</p>
  <a href="https://www.instagram.com/tanyashree_" target="_blank">
  <img class="follow_us" src="img\logo\insta.png" width=85px height=85px></a>
  <a href="https://www.facebook.com/tanyashree11635" target="_blank">
  <img class="follow_us" src="img\logo\facebook.png" width=85px height=85px></a>
  <a href="https://www.linkedin.com/in/tanya-shree-verma-3999621a4" target="_blank">
  <img class="follow_us" src="img\logo\linked.png" width=85px height=85px></a>

</div>
<div class="topnav" id="myTopnav" style="height: 45px; margin-top:-10px;">
  <a href="index.php" class="active">Home</a>
   <div class="dropdown">
    <button class="dropbtn">Select Vehicles 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="cycle.php">Cycle</a>
      <a href="car.php"> Car </a>
      <a href="bike.php">Bike</a>
      <a href="traveller.php">traveller Van</a>
    </div>
  </div> 
  <a href="#about">About</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
					<a href="account.php" style="font-size:15px;float: right;">Client Login</a>
					<a href="login.php">Admin Login</a>
					<?php
						} else{

					?>
<div class="topnav-information">
  <img class="logo" src="img\logo\logo.png" width=90px height=90px style="margin-top: 0px;">
 <a href="https://goo.gl/maps/CYubAdisUANTEca68"> <p class="commons"><img src="img\logo\location1.png" width=50px height=50px>Sanjay Place Agra</p></a>
 <a href="https://gmail.com" target="_blank"> <p class="commons"><img src="img\logo\mail.png" width=50px height=50px>contactus123@gmail.com</p></a>
  <p class="commons"><img src="img\logo\call.png" width=50px height=50px>+9808809754/9675596901</p>
  <p class ="follow_us" style="margin-left: 30px;margin-top: 30px">Follow Us On :</p>
  <a href="https://www.instagram.com/tanyashree_" target="_blank">
  <img class="follow_us" src="img\logo\insta.png" width=85px height=85px></a>
  <a href="https://www.facebook.com/tanyashree11635" target="_blank">
  <img class="follow_us" src="img\logo\facebook.png" width=85px height=85px></a>
  <a href="https://www.linkedin.com/in/tanya-shree-verma-3999621a4" target="_blank">
  <img class="follow_us" src="img\logo\linked.png" width=85px height=85px></a>

</div>
<div class="topnav" id="myTopnav" style="height: 45px; margin-bottom:35px;">
  <a href="index.php" class="active">Home</a>
   <a href="status.php">View Status</a>
  <a href="message_admin.php">Message Admin</a>
  <a href="admin/logout.php">Logout</a>
<div class="dropdown" width="100px">
    <button class="dropbtn">Select Vehicles 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="cycle.php">Cycle</a>
      <a href="car.php"> Car </a>
      <a href="bike.php">Bike</a>
      <a href="traveller.php">traveller Van</a>
    </div>


      </div> 

							
					<?php
						}
					?>
		</nav>
	</div>
</header>